
export const PORT = 3000

export const HOST = 'http://localhost:' + PORT