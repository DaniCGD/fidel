import { Router } from "express";
import {
    cancelPayment,
    captureOrder,
    createQvaPayOrder,
    createTropyPayOrder
    
} from '../controllers/payment.controllers.js';

const router = Router()

router.post('/create-qvapay-order', createQvaPayOrder)
router.post('/create-tropypay-order', createTropyPayOrder)
router.get('/capture-order', captureOrder)
router.get('/cancel-order', cancelPayment)

export default router