import { login, createInvoice } from 'qvapay-sdk';
import { Tropipay } from '@yosle/tropipayjs'

const obtainDate = () => {
    const fechaActual = new Date();
    const anio = fechaActual.getFullYear();
    const mes = fechaActual.getMonth() + 1; // Los meses en JavaScript empiezan en 0, por lo que se agrega 1
    const dia = fechaActual.getDate();

    // Agrega un cero inicial a los meses y días menores a 10
    const mesConCero = mes < 10 ? "0" + mes : mes;
    const diaConCero = dia < 10 ? "0" + dia : dia;

    // Concatena las partes de la fecha en una cadena con el formato deseado
    return `${anio}-${mesConCero}-${diaConCero}`;
}


export const createQvaPayOrder = async (req, res) => {

    const appAuth = {
        app_id: 'dfad76e2-5fc8-439d-9140-1c3f9169f8b4',
        app_secret: '6H4MzVjPT5Bh8VDMyszNF7KRK9fcjn9QtPn10trSIlxyDDbq2M',
    };
    const invoice = {
        ...appAuth,
        amount: 20,
        description: 'Amount of Garbage',
        remote_id: 'Garbage',
        signed: 1,
    };
    const session = await createInvoice(invoice);
    return res.status(200).json(session)
}

export const createTropyPayOrder = async (req, res) => {
    try {
        const config = {
            clientId: "731b38bb8c9bb19a7b6c58fc8f0ba1c4",
            clientSecret: "9e22be2f84e6f085ff1305e23c90dc55",
            serverMode: 'Development' // For production serverMode: 'Production'
        }
        const tpp = new Tropipay(config)
        const payload = {
            reference: "garbage collection",
            concept: "Garbage",
            favorite: "true",
            amount: 20,
            currency: "USD",
            description: "Garbage collection",
            singleUse: "true",
            reasonId: 4,
            expirationDays: 1,
            lang: "es",
            urlSuccess: 'http://127.0.0.1:3000/capture-order',
            urlFailed: 'http://127.0.0.1:3000/cancel-order',
            urlNotification: 'http://127.0.0.1:3000/capture-order',
            serviceDate: obtainDate(),
            directPayment: "true",
            paymentMethods: [
                "EXT",
                "TPP"
            ]
        }
        const paylink = await tpp.createPaymentCard(payload);

        res.status(200).json(paylink)
    } catch (error) {
        console.log(error)
        res.status(400).json({
            "message": {
                "error": error
            }
        })
    }
}

export const captureOrder = (req, res) => res.redirect('/success-payment.html')

export const cancelPayment = (req, res) => res.redirect('/cancel-payment.html')